package com.example.TP_JPA.repositories;

import com.example.firstapp.Entities.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Integer> {
}
